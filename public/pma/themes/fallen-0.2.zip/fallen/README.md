# Fallen (phpMyAdmin Theme)

The First amazing phpMyAdmin 4 theme in the world.

## Usage

* Download Fallen PMA Theme.
* Unzip **fallen-pma-master**.
* Rename **fallen-pma-master** to **fallen**.
* Move to your phpMyAdmin themes directory.
* Activate "Fallen" from phpMyAdmin dashboard.
* Done.

## Screenshot

![Fallen login](https://storage.googleapis.com/fransallencom.appspot.com/images/fallen-pma-3.png)

![Fallen home](https://storage.googleapis.com/fransallencom.appspot.com/images/fallen-pma.png)

![Fallen DB](https://storage.googleapis.com/fransallencom.appspot.com/images/fallen-pma-2.png)

## LICENSE

Licensed under GPL license. Please see the license file: https://github.com/fransallen/fallen-pma/LICENSE
