@media (min-width: 768px) {
  #tbl_search_form fieldset, #zoom_search_form fieldset, #find_replace_form fieldset {
    margin-top: 5px
  }

  fieldset#tableFilter {
    margin-top: 0
  }

  .tabLinks {
    margin-top: -5px;
    margin-bottom: 5px
  }
}
