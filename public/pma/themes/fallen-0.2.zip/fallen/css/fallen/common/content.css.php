#page_content {
  margin: 20px!important
}

.turnOffSelect {
  user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none
}
