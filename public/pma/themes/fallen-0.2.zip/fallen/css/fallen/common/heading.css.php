h2 img {
  display: none
}

h2 a img {
  display: inline
}
